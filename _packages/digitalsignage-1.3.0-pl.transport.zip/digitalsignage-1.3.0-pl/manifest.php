<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
Digital Signage
----------------------
Version: 1.3.0
Author: Oene Tjeerd de Bruin
Contact: modx@oetzie.nl
----------------------
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.3.0
Released: 2021-04-29
----------------------
- Bug fixes
    - Optimalisation

----------------------
Version: 1.2.0
Released: 2019-09-06
----------------------
- Bug fixes
    - Friendly URL bug
- New editor system settings
- New default template
- New slide types
    - Countdown
    - Analog clock
    - iFrame

----------------------
Version: 1.1.4
Released: 2018-05-09
----------------------
- Bug fixes

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '7e8fabb9614ee427b70773ed0d694c2e',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/3619e568a2f7630fa8f64b9fe7cf4b32.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '174c499b6e84e809bc1042f27bb3faab',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/9635d35d4aa066be6fc05b55c5802192.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'caf00b66d31e262aee82fc16ae4241b2',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/2a9a5053c6390150db89bbfb83edc058.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '918a9259eef2c48047f4f73673960d75',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/5b31e35a9a941f9db9836a142a3f3588.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c17ae03a51035f40c9b6d736a1e09f2d',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/2d3450b77dece959d4f3eb09c295bdc9.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e7f8e0acbcfbe7607f3a9a6826e6280',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/30c7353aebacee80575706c1975f9a24.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b02129029eaa95ac57cc865a96ecee67',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/d5de8f47bb4d124df68b6f91b7d56eec.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54b552180a25e30cfdc05bf06e30f273',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/6b9b6e943715ecf7c03dcd1ef45b5f8c.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1c685210f38ff1e2f5ad833019b1858',
      'native_key' => 'digitalsignage.rte_config',
      'filename' => 'modSystemSetting/e6bca735ec33fa6cc6c175db1422da4c.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '69fca153a9cdfe385cb5f97b3777b487',
      'native_key' => NULL,
      'filename' => 'modCategory/a2605e75a9af2c34ff0b36b5b0839a1b.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '33915ebc6accc3fa5bf31d19d55da10d',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/222b3e2b371012d21664c32aea68fcbd.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);