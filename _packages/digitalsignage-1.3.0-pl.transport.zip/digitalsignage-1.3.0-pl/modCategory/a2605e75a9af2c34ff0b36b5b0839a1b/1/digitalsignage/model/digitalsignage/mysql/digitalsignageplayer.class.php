<?php

/**
 * Digital Signage
 *
 * Copyright 2021 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

require_once dirname(__DIR__) . '/digitalsignageplayer.class.php';

class DigitalSignagePlayer_mysql extends DigitalSignagePlayer
{
}
