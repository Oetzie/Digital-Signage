<?php

/**
 * Digital Signage
 *
 * Copyright 2021 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

require_once dirname(__DIR__) . '/digitalsignagebroadcast.class.php';

class DigitalSignageBroadcast_mysql extends DigitalSignageBroadcast
{
}
