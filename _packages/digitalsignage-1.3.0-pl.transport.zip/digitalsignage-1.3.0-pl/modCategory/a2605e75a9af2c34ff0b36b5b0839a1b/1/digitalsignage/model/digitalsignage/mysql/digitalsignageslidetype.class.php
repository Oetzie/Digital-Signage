<?php

/**
 * Digital Signage
 *
 * Copyright 2021 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

require_once dirname(__DIR__) . '/digitalsignageslidetype.class.php';

class DigitalSignageSlideType_mysql extends DigitalSignageSlideType
{
}
